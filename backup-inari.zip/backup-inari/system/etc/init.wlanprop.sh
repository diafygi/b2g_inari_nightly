#!/system/bin/sh

setprop wifi.chip.type AR_6005
